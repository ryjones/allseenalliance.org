#!/bin/bash
echo "+++++Getting Core repos+++++"
git clone https://git.allseenalliance.org/gerrit/core/about_tcl.git ./core/about_tcl
git clone https://git.allseenalliance.org/gerrit/core/ajtcl.git ./core/ajtcl
git clone https://git.allseenalliance.org/gerrit/core/alljoyn.git ./core/alljoyn
git clone https://git.allseenalliance.org/gerrit/core/devmodules.git ./core/devmodules
git clone https://git.allseenalliance.org/gerrit/core/peergroupmanager.git ./core/peergroupmanager
echo "+++++Getting devtool repos+++++"
git clone https://git.allseenalliance.org/gerrit/devtools/codegen.git ./devtools/codegen
echo "+++++Getting multimedia repos+++++"
git clone https://git.allseenalliance.org/gerrit/multimedia/audio.git ./multimedia/audio
echo "+++++Getting services+++++"
git clone https://git.allseenalliance.org/gerrit/services/config.git ./services/config
git clone https://git.allseenalliance.org/gerrit/services/controlpanel.git ./services/controlpanel
git clone https://git.allseenalliance.org/gerrit/services/filetransfer.git ./services/filetransfer
git clone https://git.allseenalliance.org/gerrit/services/notification.git ./services/notification
git clone https://git.allseenalliance.org/gerrit/services/notification_viewer.git ./services/notification_viewer
git clone https://git.allseenalliance.org/gerrit/services/onboarding.git ./services/onboarding
git clone https://git.allseenalliance.org/gerrit/services/sample_apps.git ./services/sample_apps
git clone https://git.allseenalliance.org/gerrit/services/services_common.git ./services/services_common
git clone https://git.allseenalliance.org/gerrit/services/simulators.git ./services/simulators