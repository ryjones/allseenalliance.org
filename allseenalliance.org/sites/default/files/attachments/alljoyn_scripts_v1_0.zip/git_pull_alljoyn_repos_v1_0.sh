#!/bin/bash
echo "+++++Getting Core repos+++++"
cd ./core/about_tcl && git pull && cd -
cd ./core/ajtcl && git pull && cd -
cd ./core/alljoyn && git pull && cd -
cd ./core/devmodules && git pull && cd -
cd ./core/peergroupmanager && git pull && cd -
echo "+++++Getting devtool repos+++++"
cd ./devtools/codegen && git pull && cd -
echo "+++++Getting multimedia repos+++++"
cd ./multimedia/audio && git pull && cd -
echo "+++++Getting services+++++"
cd ./services/config && git pull && cd -
cd ./services/controlpanel && git pull && cd -
cd ./services/filetransfer && git pull && cd -
cd ./services/notification && git pull && cd -
cd ./services/notification_viewer && git pull && cd -
cd ./services/onboarding && git pull && cd -
cd ./services/sample_apps && git pull && cd -
cd ./services/services_common && git pull && cd -
cd ./services/simulators && git pull && cd -